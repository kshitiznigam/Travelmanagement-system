package travelservicesystem;

public class BookedFlights {
	
	private int flightCode;
	private int numTickets;
	private String date;
	public BookedFlights(int flightCode, int numTickets, String date) {
		this.flightCode = flightCode;
		this.numTickets = numTickets;
		this.date = date;
	}
	@Override
	public String toString() {
		return "BookedFlights [flightCode=" + flightCode + ", numTickets=" + numTickets + ", date=" + date + "]";
	}
}
