package travelservicesystem;

import java.util.*;

public class FlightRegistration {
	
	private int code;
    private String name;
    private int capacity;
    private boolean isActive;
    private String source;
    private String destination;
    private String date;
    private int booked;
    private int remaining;
    List<CustomersDetails> customersDetails;
    
    public int getBooked() {
		return booked;
	}

	public void setBooked(int booked) {
		this.booked = booked;
	}

	public int getRemaining() {
		return remaining;
	}

	public void setRemaining(int remaining) {
		this.remaining = remaining;
	}

	public void bookTicket(int numTickets) {
    	if(remaining < numTickets) {
    		System.out.println("Sorry, tickets are not available..");
    		return;
    	}
    	this.booked += numTickets;
    	this.remaining -= numTickets;
    }
    
	public FlightRegistration(int code, String name, int capacity, boolean isActive, String source, String destination,
			String date) {
		this.code = code;
		this.name = name;
		this.capacity = capacity;
		this.isActive = isActive;
		this.source = source;
		this.destination = destination;
		this.date = date;
		this.booked = 0;
		this.remaining = capacity;
		customersDetails = new ArrayList<>();
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "FlightRegistration [code=" + code + ", name=" + name + ", capacity=" + capacity + ", isActive="
				+ isActive + ", source=" + source + ", destination=" + destination + ", date=" + date + ", booked="
				+ booked + ", remaining=" + remaining + "]";
	}
	
}
