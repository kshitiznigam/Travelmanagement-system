package travelservicesystem;
import java.util.*;

public class Implementation {
	
	//list contains all customer data
	static List<CustomerRegistration> customersList = new ArrayList<>();
	
	// contains only active flights list
	static List<FlightRegistration> availableFlights = new ArrayList<>();
	
	public static FlightRegistration searchFlightByCode(int flightCode) {
		  for(FlightRegistration flight : availableFlights) {
				if(flight.getCode() == flightCode) {
					return flight;
				}
		  }
		  return null;
	}
	
	public static CustomerRegistration searchCustomerById(int customerId) {
		  for(CustomerRegistration cr : customersList) {
				if(cr.getId() == customerId) {
					return cr;
				}
		  }
		  return null;
	}

	public static void main(String[] args) {
		
	  Scanner sc = new Scanner(System.in);
	  
	  while(true) {
		  System.out.println("Please select options from the following : ");
		  System.out.println("1. Flight Registration");
          System.out.println("2. Flight Search");
          System.out.println("3. Customer Registration");
          System.out.println("4. Tickets Booking");
          System.out.println("5. All Customers Data");
          System.out.println("6. All Flights Data");
          System.out.println("7. Tickets Booking History");
          System.out.println("8. Flight Passenger list");
          System.out.println("0. Exit");
          System.out.println();
          
          int request = sc.nextInt();
          
          if(request == 1) {
        	  System.out.println("Enter Flight Details");
              System.out.print("Flight Code : ");
              int code = sc.nextInt();
              System.out.print("Flight Name : ");
              String name = sc.next();
              System.out.print("Flight Capacity : ");
              int capacity = sc.nextInt();
              System.out.print("Flight Status (Enter true for active and false for inactive) : ");
              boolean isActive = sc.nextBoolean();
              System.out.print("Flight Source : ");
              String source = sc.next();
              System.out.print("Flight Destination : ");
              String destination = sc.next();
              System.out.print("Flight Date of Journey (Enter in dd/mm/yyyy format) : ");
              String date = sc.next();
              System.out.println("Flight Registration is successful");
              FlightRegistration fr = new FlightRegistration(code, name, capacity, isActive, source, destination, date);
              System.out.println(fr.toString());
            	  availableFlights.add(fr);
          }else if(request == 2) {
        	  System.out.print("Enter your source : ");
        	  String userSource = sc.next();
        	  System.out.print("Enter your destination :");
        	  String userDestination = sc.next();
        	  System.out.print("Enter date of Journey : ");
        	  String userDate = sc.next();
        	  
        	  int count = 0;
        	  for(FlightRegistration temp : availableFlights) {
        		  if(temp.isActive() == true && temp.getSource().equals(userSource) && temp.getDestination().equals(userDestination) && temp.getDate().equals(userDate)) {
        		    System.out.println(temp.toString());
        		    count++ ;
        		  }
        	  }  
        	  if(count == 0) {
        		  System.out.println("Sorry, flights are not available..");
        	  }
          }else if(request == 3) {
        	  System.out.print("Enter user name : ");
        	  String name = sc.next();
        	  System.out.print("Enter user mobile number : ");
        	  long mobileNumber = sc.nextLong();
        	  System.out.print("Enter user id : ");
        	  int id = sc.nextInt();
        	  System.out.println("Customer registration successful");
        	  CustomerRegistration cr = new CustomerRegistration(name, mobileNumber, id);
        	  cr.toString();
        	  customersList.add(cr);
          }else if(request == 4) {
        	  System.out.println("Enter flight code : ");
        	  int flightCode = sc.nextInt();
        	  FlightRegistration flightToBeBooked = searchFlightByCode(flightCode);
        	  
        	  System.out.println("Enter Customer Id :");
        	  int customerId = sc.nextInt();
        	  CustomerRegistration customer = searchCustomerById(customerId);
        	  
        	  if(customer == null) {
        		  System.out.println("Invalid Customer Id");
        		  continue;
        	  }
        	  
        	  if(flightToBeBooked == null) {
        		  System.out.println("OOPS! No flights with flight Code :" + flightCode);
        	  }else {
        		  System.out.println(flightToBeBooked.toString());
        		  System.out.println("Enter no.of tickets : ");
        		  int numOfTickets = sc.nextInt();
        		  if(flightToBeBooked.getRemaining() < numOfTickets) {
        			  System.out.println("Sorry " + numOfTickets + "are not available");
        		  }else {
        			  flightToBeBooked.bookTicket(numOfTickets);
        			  BookedFlights booked = new BookedFlights(flightToBeBooked.getCode(), numOfTickets, flightToBeBooked.getDate());
        			  customer.bookedFlights.add(booked);
        			  CustomersDetails cd = new CustomersDetails(numOfTickets, customerId);
        			  flightToBeBooked.customersDetails.add(cd);
        		  }
        	  }  
          }else if(request == 5) {
        	  System.out.println("All Available customers data : ");
        	  if(customersList.size() == 0) {
        		  System.out.println("No Customers are present");
        	  }
        	  for(CustomerRegistration customer : customersList) {
        		  System.out.println(customer.toString());
        	  }
          }else if(request == 6) {
        	  System.out.println("All Flights data : ");
        	  if(availableFlights.size() == 0) {
        		  System.out.println("No Flights are available");
        	  }
        	  for(FlightRegistration flight : availableFlights) {
        		  System.out.println(flight.toString());
        	  }
          }else if(request == 7) {
        	  System.out.println("Enter your customer Id : ");
        	  int cus_id = sc.nextInt();
        	  CustomerRegistration cust = searchCustomerById(cus_id);
        	  if(cust == null) {
        		  System.out.println("Invalid Customer Id");
        		  continue;
        	  }
        	  List<BookedFlights> bookedFlightsList = cust.bookedFlights;
        	  for(BookedFlights list : bookedFlightsList) {
        		System.out.println(list.toString());  
        	  }
          }else if(request == 8) {
        	  System.out.println("Enter flight code : ");
        	  int code = sc.nextInt();
        	  FlightRegistration f = searchFlightByCode(code);
        	  if(f == null) {
        		  System.out.println("Invalid Flight Code");
        		  continue;
        	  }
        	  List<CustomersDetails> customerDetailsList = f.customersDetails;
        	  for(CustomersDetails c : customerDetailsList) {
        		  System.out.println(c.toString());
        	  }
          }else if(request == 0) {
        	  System.exit(0);
          }else {
        	  System.out.println("Please enter a valid number between 0 and 8");
          }  
	  }
	}
}