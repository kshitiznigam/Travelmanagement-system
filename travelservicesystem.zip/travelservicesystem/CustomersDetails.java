package travelservicesystem;

public class CustomersDetails {
	
	private int numTickets;
	private int id;
	public CustomersDetails(int numTickets, int id) {
		this.numTickets = numTickets;
		this.id = id;
	}
	@Override
	public String toString() {
		return "CustomersDetails [numTickets=" + numTickets + ", id=" + id + "]";
	}

}
