package travelservicesystem;

import java.util.*;

public class CustomerRegistration {
	
	private String name;
	private long mobileNumber;
	private int id;
	List<BookedFlights> bookedFlights;
	
	public CustomerRegistration(String name, long mobileNumber, int id) {
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.id = id;
		bookedFlights = new ArrayList<>();
	}
	
	@Override
	public String toString() {
		return "CustomerRegistration [name=" + name + ", mobileNumber=" + mobileNumber + ", id=" + id + "]";
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}
